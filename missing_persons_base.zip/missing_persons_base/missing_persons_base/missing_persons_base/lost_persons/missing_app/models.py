from django.db import models

# Create your models here.
class MissPerson(models.Model) :
    date_missing = models.DateField()
    last_name = models.CharField(max_length=20)
    first_name = models.CharField(max_length=20)
    age_at_missing = models.IntegerField()
    city = models.CharField(max_length=20)
    state = models.CharField(max_length=5)
    gender = models.CharField(max_length=5)
    race = models.CharField(max_length=5)

    def __str__(self) :
        return (self.full_name)
    
    @property
    def full_name(self) :
        return '%s %s' % (self.first_name, self.last_name)
    
    def save(self) :
        self.first_name = self.first_name.upper()
        self.last_name = self.last_name.upper()
        self.city = self.city.capitalize()
        self.state = self.state.upper()
        self.race = self.race.upper()
        super(MissPerson, self).save()
    