#You need to import the render function in order to call it
from django.shortcuts import render
from .models import MissPerson

#This is the name of the view function that will be called by the “” url
def indexPageView(request) :       
    return render(request, 'missing_app/index.html')

def basePageView(request) :
    return render(request, 'missing_app/base.html')

def aboutPageView(request) :

    db_students = MissPerson.objects.all()
    context = {
        "data" : db_students,
    }
    return render(request,'missing_app/about.html', context)


def showDataPageView(request, id) :
    missing_person = MissPerson.objects.get(id=id)

    context = {
        "data": missing_person  
    }
    
    return render(request, 'missing_app/showData.html', context)