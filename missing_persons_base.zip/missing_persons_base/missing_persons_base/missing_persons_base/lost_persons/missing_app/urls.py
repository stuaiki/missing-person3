from django.urls import path
from .views import indexPageView, aboutPageView, basePageView, showDataPageView
            
urlpatterns = [
    path("showData/<int:id>/", showDataPageView, name="showData"),
    path("about/", aboutPageView, name="about"),
    path("base/", basePageView, name="base"),
    path("", indexPageView, name="index"),
]
